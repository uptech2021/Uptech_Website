import React from 'react';

interface ApplicationDetailsModalProps {
    application: {
        firstName: string;
        lastName: string;
        position: string;
        phone: string;
        email: string;
        resumeUrl?: string;
        portfolio?: {
            fileUrl?: string;
            webUrl?: string;
        };
        status: string;
    };
    onClose: () => void;
}

export default function ApplicationDetailsModal({ application, onClose }: ApplicationDetailsModalProps) {
    return (
        <div id="applicationModal" className="fixed inset-0 bg-gray-600 bg-opacity-50">
            <div className="relative top-20 mx-auto p-5 border w-11/12 md:w-2/3 lg:w-1/2 shadow-lg rounded-md bg-white">
                <div className="mt-3">
                    <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">Application Details</h3>
                    <div id="modalContent" className="space-y-4">
                        <table>
                            <thead>
                                <tr>
                                    <th>First Name</th>
                                    <th>Last Name</th>
                                    <th>Position</th>
                                    <th>Contact Number</th>
                                    <th>Email</th>
                                    <th>Resume</th>
                                    <th>Portfolio</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>{application.firstName}</td>
                                    <td>{application.lastName}</td>
                                    <td>{application.position}</td>
                                    <td>{application.phone}</td>
                                    <td>{application.email}</td>
                                    <td>{application.resumeUrl ? <a href={application.resumeUrl} target="_blank" className="text-blue-600">View Resume</a> : 'N/A'}</td>
                                    <td>{application.portfolio?.fileUrl ? <a href={application.portfolio.fileUrl} target="_blank" className="text-purple-600">View Portfolio</a> : 'N/A'}</td>
                                    <td>{application.status}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div className="mt-5 flex justify-end gap-4">
                        <button onClick={onClose} className="px-4 py-2 bg-gray-100 text-gray-800 rounded-md hover:bg-gray-200">Close</button>
                        <button className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600">Update Status</button>
                    </div>
                </div>
            </div>
        </div>
    );
}